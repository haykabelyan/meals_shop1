


export function Footer(){


    return <div className="Footer"></div>
}