


export function NotFoundPage(){


    return <div className="NotFoundPage">
        NotFoundPage
    </div>
}