

export function ContactPage(){


    return <div className="ContactPage">
        ContactPage
    </div>
}