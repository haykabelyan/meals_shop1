

export function AboutPage(){


    return <div className="AboutPage">
        AboutPage
    </div>
}